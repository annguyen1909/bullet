$ErrorActionPreference = 'Stop'

Write-Host "Packaging project (excluding node_modules) ..." -ForegroundColor Cyan

$root = $PSScriptRoot
$pkgPath = Join-Path $root 'package.json'
if (!(Test-Path $pkgPath)) { throw "package.json not found in $root" }
$pkg = Get-Content $pkgPath | ConvertFrom-Json

$name = if ($pkg.name) { $pkg.name } else { 'bullet-improver' }
$name = ($name -replace '[^a-zA-Z0-9._-]', '-')
$version = if ($pkg.version) { $pkg.version } else { '1.0.0' }
$basename = "$name-$version"

$dist = Join-Path $root 'dist'
if (!(Test-Path $dist)) { New-Item -ItemType Directory -Path $dist | Out-Null }
$stage = Join-Path $dist $basename

if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
New-Item -ItemType Directory -Path $stage | Out-Null

# Use robocopy for reliable directory exclusions on Windows PowerShell 5.1
$excludeDirs = @('node_modules', '.git', 'dist', '.vscode')
$excludeFiles = @('.env', '*.log')

$xdArgs = @()
foreach ($d in $excludeDirs) { $xdArgs += @('/XD', $d) }

$xfArgs = @()
foreach ($f in $excludeFiles) { $xfArgs += @('/XF', $f) }

$roboArgs = @($root, $stage, '/MIR') + $xdArgs + $xfArgs

Write-Host "Copying files to staging ..." -ForegroundColor DarkCyan
& robocopy @roboArgs | Out-Null
$rc = $LASTEXITCODE
# robocopy returns 0-7 for success; >=8 indicates failure
if ($rc -ge 8) { throw "robocopy failed with exit code $rc" }

$zipPath = Join-Path $dist ("$basename.zip")
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }

Write-Host "Creating archive $zipPath ..." -ForegroundColor DarkCyan
Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $zipPath -Force

# Optional: clean staging folder after packaging
Remove-Item $stage -Recurse -Force

Write-Host "Done: $zipPath" -ForegroundColor Green