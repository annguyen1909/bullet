# Resume Bullet Improver

Minimal, polished web app to improve resume bullets using an Express API and OpenAI (with a no-key local fallback).

## Quick Start

1. Create `.env` (optional for real LLM):

```
cp .env.example .env
# Then set OPENAI_API_KEY in .env (optional)
```

2. Install and run:

```
npm install
npm start
```

Open http://localhost:3000

- Without `OPENAI_API_KEY`, the API returns plausible offline improvements.
- With `OPENAI_API_KEY`, it will call OpenAI (model defaults to `gpt-4o-mini`).

## API

POST `/api/improve`

Input:

```
{
  "bullet": "string",
  "style": "Impactful|Technical|Metrics-Focused|Concise"
}
```

Output:

```
{ "results": ["...", "...", "..."] }
```

## Deploy

- Render: use `npm start` and set `OPENAI_API_KEY` env var.
- Vercel: this project runs as a simple Node server; you can deploy via a Node build or adapt by moving the Express logic into a Vercel serverless function. The current structure matches local/dev and Render easily.

## Notes

- Frontend uses plain CSS + vanilla JS, no build step.
- Error handling and loading states are included. Copy buttons for each result.